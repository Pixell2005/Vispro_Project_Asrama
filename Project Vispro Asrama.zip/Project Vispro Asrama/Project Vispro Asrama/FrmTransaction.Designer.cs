﻿namespace Project_Vispro_Asrama
{
    partial class FrmTransaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnBayar = new System.Windows.Forms.Button();
            this.lblLastBalance = new System.Windows.Forms.Label();
            this.lblNama = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblNIM = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblFoto = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtUang = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNIM = new System.Windows.Forms.TextBox();
            this.txtBalance = new System.Windows.Forms.TextBox();
            this.txtNama = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(85, 220);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(295, 51);
            this.label1.TabIndex = 5;
            this.label1.Text = "Last Balance :";
            // 
            // btnBayar
            // 
            this.btnBayar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBayar.Location = new System.Drawing.Point(1331, 861);
            this.btnBayar.Name = "btnBayar";
            this.btnBayar.Size = new System.Drawing.Size(117, 57);
            this.btnBayar.TabIndex = 6;
            this.btnBayar.Text = "Bayar";
            this.btnBayar.UseVisualStyleBackColor = true;
            this.btnBayar.Click += new System.EventHandler(this.btnBayar_Click);
            // 
            // lblLastBalance
            // 
            this.lblLastBalance.AutoSize = true;
            this.lblLastBalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastBalance.Location = new System.Drawing.Point(440, 245);
            this.lblLastBalance.Name = "lblLastBalance";
            this.lblLastBalance.Size = new System.Drawing.Size(57, 20);
            this.lblLastBalance.TabIndex = 7;
            this.lblLastBalance.Text = "............";
            // 
            // lblNama
            // 
            this.lblNama.AutoSize = true;
            this.lblNama.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNama.Location = new System.Drawing.Point(440, 121);
            this.lblNama.Name = "lblNama";
            this.lblNama.Size = new System.Drawing.Size(57, 20);
            this.lblNama.TabIndex = 9;
            this.lblNama.Text = "............";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(219, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 51);
            this.label4.TabIndex = 8;
            this.label4.Text = "Nama :";
            // 
            // lblNIM
            // 
            this.lblNIM.AutoSize = true;
            this.lblNIM.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNIM.Location = new System.Drawing.Point(440, 182);
            this.lblNIM.Name = "lblNIM";
            this.lblNIM.Size = new System.Drawing.Size(57, 20);
            this.lblNIM.TabIndex = 11;
            this.lblNIM.Text = "............";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(256, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 51);
            this.label6.TabIndex = 10;
            this.label6.Text = "NIM :";
            // 
            // lblFoto
            // 
            this.lblFoto.AutoSize = true;
            this.lblFoto.Location = new System.Drawing.Point(1074, 619);
            this.lblFoto.Name = "lblFoto";
            this.lblFoto.Size = new System.Drawing.Size(62, 16);
            this.lblFoto.TabIndex = 17;
            this.lblFoto.Text = "Pilih Foto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(950, 446);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(443, 38);
            this.label2.TabIndex = 16;
            this.label2.Text = "Masukkan Bukti Pembayaran";
            // 
            // txtUang
            // 
            this.txtUang.Location = new System.Drawing.Point(1119, 395);
            this.txtUang.Name = "txtUang";
            this.txtUang.Size = new System.Drawing.Size(275, 22);
            this.txtUang.TabIndex = 14;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(957, 494);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(280, 269);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(950, 380);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 38);
            this.label3.TabIndex = 12;
            this.label3.Text = "Uang :";
            // 
            // txtNIM
            // 
            this.txtNIM.Location = new System.Drawing.Point(409, 180);
            this.txtNIM.Name = "txtNIM";
            this.txtNIM.Size = new System.Drawing.Size(275, 22);
            this.txtNIM.TabIndex = 18;
            // 
            // txtBalance
            // 
            this.txtBalance.Location = new System.Drawing.Point(409, 243);
            this.txtBalance.Name = "txtBalance";
            this.txtBalance.Size = new System.Drawing.Size(275, 22);
            this.txtBalance.TabIndex = 19;
            // 
            // txtNama
            // 
            this.txtNama.Location = new System.Drawing.Point(409, 119);
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(275, 22);
            this.txtNama.TabIndex = 20;
            // 
            // FrmTransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Project_Vispro_Asrama.Properties.Resources._088154ee_ea75_4205_a165_94cf32fb3b0c;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1478, 940);
            this.Controls.Add(this.txtNama);
            this.Controls.Add(this.txtBalance);
            this.Controls.Add(this.txtNIM);
            this.Controls.Add(this.lblFoto);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtUang);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblNIM);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblNama);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblLastBalance);
            this.Controls.Add(this.btnBayar);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmTransaction";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmTransaction";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmTransaction_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBayar;
        private System.Windows.Forms.Label lblLastBalance;
        private System.Windows.Forms.Label lblNama;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblNIM;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblFoto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtUang;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNIM;
        private System.Windows.Forms.TextBox txtBalance;
        private System.Windows.Forms.TextBox txtNama;
    }
}